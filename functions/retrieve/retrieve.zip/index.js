const { S3 } = require("aws-sdk");
const imageType = require("image-type");

const s3 = new S3({ apiVersion: "latest" });

const notFound = {
  statusCode: 404,
  body: null,
};

const isNotImage = (s3Response) =>
  !/^image\/.*$/.test(s3Response.ContentType) || !imageType(s3Response.data);

exports.handler = async (event) => {
  const {
    pathParameters: { name },
  } = event;

  if (!name) return notFound;

  try {
    const s3Response = await s3
      .getObject({
        Bucket: "image-repo-obonobo",
        Key: name,
      })
      .promise();

    // if (isNotImage(s3Response)) return notFound;

    const imagePayload = Buffer.from(s3Response.Body.data).toString("base64");

    const response = {
      statusCode: 200,
      isBase64Encoded: true,
      headers: { "Content-Type": s3Response.ContentType },
      body: imagePayload,
    };
    return response;
  } catch (err) {
    // return {
    //   statusCode: 200,
    //   err,
    //   event,
    // };

    console.log(err);
    throw err;
  }
};
