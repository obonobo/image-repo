const { S3 } = require("aws-sdk");
const multipart = require("aws-lambda-multipart-parser");
const multiparty = require("multiparty");


const s3 = new S3({ apiVersion: "latest" });

const responseHeaders = {
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST,GET",
};

exports.handler = async (event) => {

  const form = new multiparty.Form();

  form.parse()

  const parsed = multipart.parse(event);
  const decodedImage = Buffer.from(parsed["cat2.jpeg"].content, "base64");
  const s3Params = {
    Bucket: "image-repo-obonobo",
    ContentType: "image/jpeg",
    Key: "cat6.jpeg",
    Body: decodedImage,
  };

  try {
    await s3.upload(s3Params).promise();
    return {
      statusCode: 200,
      headers: responseHeaders,
      body: "Upload success!",
    };
  } catch (err) {
    console.log(err);
    throw err;
  }
};



// const { S3 } = require("aws-sdk");
// const multipart = require("aws-lambda-multipart-parser");
// const http = require("http");

// const s3 = new S3({ apiVersion: "latest" });

// const responseHeaders = {
//   "Access-Control-Allow-Headers": "Content-Type",
//   "Access-Control-Allow-Origin": "*",
//   "Access-Control-Allow-Methods": "POST,GET",
// };

// exports.handler = async (event) => {

//   // const decoded = Buffer.from(event.body, "base64").toString("UTF-8");
//   const decoded = Buffer.from(event.body, "base64").toString("ascii");
//   // const decoded = Buffer.from(event.body, "base64");

//   // const parsed = http.parse(decoded);

//   // const asJson = JSON.parse(decoded);
//   const asJson = decoded;

//   return {
//     statusCode: 200,
//     headers: responseHeaders,
//     body: JSON.stringify({
//       // parsed: parsed,
//       headers: event.headers,
//       b64: decoded,
//       parsedb64: asJson,
//       raw: event,
//     }),
//   };


//   // const parsed = multipart.parse(event);
//   // const decodedImage = Buffer.from(parsed["cat2.jpeg"].content, "base64");
//   // const s3Params = {
//   //   Bucket: "image-repo-obonobo",
//   //   ContentType: "image/jpeg",
//   //   Key: "cat6.jpeg",
//   //   Body: decodedImage,
//   // };

//   // try {
//   //   await s3.upload(s3Params).promise();
//   //   return {
//   //     statusCode: 200,
//   //     headers: responseHeaders,
//   //     body: "Upload success!",
//   //   };
//   // } catch (err) {
//   //   console.log(err);
//   //   throw err;
//   // }
// };
